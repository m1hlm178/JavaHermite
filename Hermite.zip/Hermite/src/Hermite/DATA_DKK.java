//    public void Fungsi1(int i,float x){
//        DefaultTableModel Input_Table = (DefaultTableModel) Table_Input.getModel();
//        double answera = round((x*Math.log(x)),7);
//        double answerb = round((Math.log(x)+1),7);
//        System.out.println(roundf(x,1));
//        Input_Table.addRow(new Object[]{i,x,answera,answerb});
//        Label_Aprox.setText("Aprox : F(" + Numx +")");
//        float nilaix = Float.parseFloat(TXT_KN.getText());
//        double hasil = round((nilaix*Math.log(nilaix)),7);
//        Eksak_Nilai.setText(String.valueOf(hasil));
//    }
//    
//    public void Fungsi2(int i,float x){
//        DefaultTableModel Input_Table = (DefaultTableModel) Table_Input.getModel();
//        double answera = round(((x*Math.cos(x))-(2*Math.pow(x, 2))+(3*x-1)),7);
//        double answerb = round((Math.cos(x)-(x*Math.sin(x))-(4*x)),7);
//        System.out.println(roundf(x,1));
//        Input_Table.addRow(new Object[]{i,x,answera,answerb});
//        Label_Aprox.setText("Aprox : F(" + Numx +")");
//        float nilaix = Float.parseFloat(TXT_KN.getText());
//        double hasil = round(((nilaix*Math.cos(x))-(2*Math.pow(nilaix, 2))+(3*nilaix-1)),7);
//        Eksak_Nilai.setText(String.valueOf(hasil));
//    }
//    
//    public void Fungsi3(int i,float x){
//        DefaultTableModel Input_Table = (DefaultTableModel) Table_Input.getModel();
//        double answera = round(((Math.pow(x, 3)+(4.001*Math.pow(x, 2))+(4.002*x)+1.101)),7);
//        double answerb = round(((3*Math.pow(x, 2))+(8.002*x)+4.002),7);
//        System.out.println(roundf(x,1));
//        Input_Table.addRow(new Object[]{i,x,answera,answerb});
//        Label_Aprox.setText("Aprox : F(" + Numx +")");
//        float nilaix = Float.parseFloat(TXT_KN.getText());
//        double hasil = round(((Math.pow(nilaix, 3)+(4.001*Math.pow(nilaix, 2))+(4.002*nilaix)+1.101)),7);
//        Eksak_Nilai.setText(String.valueOf(hasil));
//    }
//    
//    public void Fungsi4(int i,float x){
//        DefaultTableModel Input_Table = (DefaultTableModel) Table_Input.getModel();
//        double answera = round(Math.sin((Math.exp(x)-2)),7);
//        double answerb = round(Math.sin((Math.exp(x)*Math.cos((Math.exp(2)-2)))),7);
//        System.out.println(roundf(x,1));
//        Input_Table.addRow(new Object[]{i,x,answera,answerb});
//        Label_Aprox.setText("Aprox : F(" + Numx +")");
//        float nilaix = Float.parseFloat(TXT_KN.getText());
//        double hasil = round(Math.sin((Math.exp(nilaix)-2)),7);
//        Eksak_Nilai.setText(String.valueOf(hasil));
//    }
//    
//    public void Fungsi5(int i,float x){
//        DefaultTableModel Input_Table = (DefaultTableModel) Table_Input.getModel();
//        double answera = round(Math.pow(Math.E,(2*x)),7);
//        double answerb = round((2*Math.pow(Math.E,(2*x))),7);
//        System.out.println(roundf(x,1));
//        Input_Table.addRow(new Object[]{i,x,answera,answerb});
//        Label_Aprox.setText("Aprox : F(" + Numx +")");
//        float nilaix = Float.parseFloat(TXT_KN.getText());
//        double hasil = round(Math.pow(Math.E,(2*nilaix)),7);
//        Eksak_Nilai.setText(String.valueOf(hasil));
//    }

//    public void Input(){
//        i=Table_Input.getRowCount();
////        Numx = Float.parseFloat(TXT_X2.getText());
//        switch(choice){
//            case 1:
//                Fungsi1(i,Numx);
//                break;
//            case 2:
//                Fungsi2(i,Numx);
//                break;
//            case 3:
//                Fungsi3(i,Numx);
//                break;
//            case 4:
//                Fungsi4(i,Numx);
//                break;
//            case 5:
//                Fungsi5(i,Numx);
//                break;
//        }
//    }